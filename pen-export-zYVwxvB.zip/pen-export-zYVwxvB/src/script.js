document.getElementById('registration-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const studentNumber = document.getElementById('student-number').value;
    const yearLevel = document.getElementById('year-level').value;
    const section = document.getElementById('section').value;
    const address = document.getElementById('address').value;
    const age = document.getElementById('age').value;
    const weight = document.getElementById('weight').value;
    const height = document.getElementById('height').value;

    if (name && studentNumber && yearLevel && section && address && age && weight && height) {
        const bmi = calculateBMI(weight, height);

        const studentProfile = {
            name,
            studentNumber,
            yearLevel,
            section,
            address,
            age,
            weight,
            height,
            bmi
        };

        let students = JSON.parse(localStorage.getItem('students')) || [];
        students.push(studentProfile);
        localStorage.setItem('students', JSON.stringify(students));

        document.getElementById('form-message').textContent = 'Student registered successfully!';
        document.getElementById('form-message').style.color = 'green';
        document.getElementById('registration-form').reset();
        document.getElementById('bmi').value = '';
    } else {
        document.getElementById('form-message').textContent = 'Please fill in all fields correctly.';
        document.getElementById('form-message').style.color = 'red';
    }
});

document.getElementById('weight').addEventListener('input', updateBMI);
document.getElementById('height').addEventListener('input', updateBMI);

function updateBMI() {
    const weight = document.getElementById('weight').value;
    const height = document.getElementById('height').value;

    if (weight && height) {
        const bmi = calculateBMI(weight, height);
        document.getElementById('bmi').value = bmi;
    }
}

function calculateBMI(weight, height) {
    height = height / 100; // Convert cm to meters
    return (weight / (height * height)).toFixed(2);
}
